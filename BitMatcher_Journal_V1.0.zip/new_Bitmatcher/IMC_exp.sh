rm results/IMC/mem_2_short_hh00002.txt
rm results/IMC/mem_2_short_frequency.txt#

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 0.9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_hh00002.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a hh -h 0.00002









./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 2 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 4 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 6 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 7 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 8 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 9 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency

./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 10 -b 64 -t 4 -e 5 -f 8 -l 2 -u 1 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 10 -b 64 -t 4 -e 5 -f 8 -l 2 -u 2 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/IMC/mem_2_short_frequency.txt -m 10 -b 64 -t 4 -e 5 -f 8 -l 2 -u 3 -p 12 -a frequency