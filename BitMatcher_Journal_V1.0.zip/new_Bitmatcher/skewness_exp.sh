rm results/skewness/mem_1_big_frequency.txt



./bitmatcher4 -d /share/zipf_2022/zipf_0.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_3.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 3 -p 12 -a frequency


./bitmatcher4 -d /share/zipf_2022/zipf_0.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_3.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 1 -p 12 -a frequency



./bitmatcher4 -d /share/zipf_2022/zipf_0.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_0.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_1.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.2.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.4.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.6.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_2.8.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
./bitmatcher4 -d /share/zipf_2022/zipf_3.0.dat -o results/skewness/mem_1_big_frequency.txt -m 1 -b 64 -t 4 -e 5 -f 8 -l 1 -u 2 -p 12 -a frequency
