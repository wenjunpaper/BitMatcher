rm results/params/key_short_CAIDA_hh001.txt
rm results/params/key_short_CAIDA_hh00002.txt
rm results/params/key_short_CAIDA_frequency.txt

rm results/params/key_long_CAIDA_hh001.txt
rm results/params/key_long_CAIDA_hh00002.txt
rm results/params/key_long_CAIDA_frequency.txt

./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002



./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a frequency


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a frequency


./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 4 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 5 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 6 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 7 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a frequency






./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.1 -b 128 -t 4 -e 7 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.3 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh001.txt -m 0.5 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.001


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.1 -b 128 -t 4 -e 7 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.00002


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.3 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.00002


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_hh00002.txt -m 0.5 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a hh -h 0.00002



./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 9 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 10 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 11 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 12 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.1 -b 128 -t 4 -e 7 -f 13 -l 2 -u 0 -p 12 -a frequency


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.3 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a frequency


./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 9 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 10 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 11 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 12 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/key_long_CAIDA_frequency.txt -m 0.5 -b 128 -t 4 -e 5 -f 13 -l 2 -u 0 -p 12 -a frequency
