rm results/params/types_short_CAIDA_hh001.txt
rm results/params/types_short_CAIDA_hh00002.txt
rm results/params/types_short_CAIDA_frequency.txt


./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001





./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002





./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency
./bitmatcher -d ../data/1.dat -o results/params/types_short_CAIDA_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency




./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh001.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.001





./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 4 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_hh00002.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a hh -h 0.00002





./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 2 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 3 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 2 -e 5 -f 8 -l 2 -u 0 -p 4 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 5 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 6 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 7 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 3 -e 5 -f 8 -l 2 -u 0 -p 8 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 9 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 10 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 11 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 13 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 14 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 15 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 16 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 17 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 18 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 19 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 20 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 21 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 22 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 23 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 24 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 25 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 26 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 27 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 28 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.1 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.3 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency
./bitmatcher -d /share/IMC_DC_IP_trace/univ1/temp.dat -o results/params/types_short_IMC_frequency.txt -m 0.5 -b 64 -t 5 -e 5 -f 8 -l 2 -u 0 -p 29 -a frequency