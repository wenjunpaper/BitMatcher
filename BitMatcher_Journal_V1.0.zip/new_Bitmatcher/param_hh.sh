rm results/params/hh_small_short_CAIDA.txt
rm results/params/hh_small_long_CAIDA.txt
rm results/params/hh_big_short_CAIDA.txt
rm results/params/hh_big_long_CAIDA.txt



./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0002
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0003
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0004
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0005
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0006
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0007
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0008
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0009
./bitmatcher -d ../data/1.dat -o results/params/hh_small_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.1 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.3 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_short_CAIDA.txt -m 0.5 -b 64 -t 4 -e 5 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.1 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.3 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001

./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00001
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00002
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00003
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00004
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00005
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00006
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00007
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00008
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.00009
./bitmatcher -d ../data/1.dat -o results/params/hh_big_long_CAIDA.txt -m 0.5 -b 128 -t 4 -e 7 -f 8 -l 2 -u 0 -p 12 -a hh -h 0.0001




