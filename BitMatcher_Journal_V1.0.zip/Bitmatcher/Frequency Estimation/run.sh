rm insert.txt
rm query.txt
rm aae.txt
rm are.txt

#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.01
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.1
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 1
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 2
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 3
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 4
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 5
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 6
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 7
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 8
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 9
#./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 10

./bitmatcher ../../real_data/1.dat 0.01
./bitmatcher ../../real_data/1.dat 0.1
./bitmatcher ../../real_data/1.dat 0.2
./bitmatcher ../../real_data/1.dat 0.3
./bitmatcher ../../real_data/1.dat 0.4
./bitmatcher ../../real_data/1.dat 0.5
./bitmatcher ../../real_data/1.dat 0.6
./bitmatcher ../../real_data/1.dat 0.7
./bitmatcher ../../real_data/1.dat 0.8
./bitmatcher ../../real_data/1.dat 0.9
./bitmatcher ../../real_data/1.dat 1
./bitmatcher ../../real_data/1.dat 10



