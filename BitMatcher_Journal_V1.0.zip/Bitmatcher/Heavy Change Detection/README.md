# BitMatcher Heavy Change Detection

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./bitmatcher ./XX.data (Memory)
```

`XX.data` is a dataset, Memory is the memory usage (unit is MB).

Besides, you can also repeat the heavy change experiments of Bitmatcher by running run.sh in this folder. The result will be written into three files, they are respectively aae.txt, are.txt, f1.txt, represent the three metrics we use. The content of each line is: memory, CM result, A result, DHS result, PCU result ,BM result, EL result, nitro result SALSA result, SW result. It should be noted that you need to switch the dataset in the script to your own.

## Output format

Our program will print the F1-score, ARE, AAE of BitMatcher and other eight sketches.
