rm aae.txt
rm are.txt
rm f1.txt

./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.1
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.2
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.3
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.4
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.5
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.6
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.7
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.8
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 0.9
./bitmatcher /share/IMC_DC_IP_trace/univ1/temp.dat 1


#./bitmatcher ../../real_data/1.dat 0.1
#./bitmatcher ../../real_data/1.dat 0.2
#./bitmatcher ../../real_data/1.dat 0.3
#./bitmatcher ../../real_data/1.dat 0.4
#./bitmatcher ../../real_data/1.dat 0.5
#./bitmatcher ../../real_data/1.dat 0.6
#./bitmatcher ../../real_data/1.dat 0.7
#./bitmatcher ../../real_data/1.dat 0.8
#./bitmatcher ../../real_data/1.dat 0.9
#./bitmatcher ../../real_data/1.dat 1
