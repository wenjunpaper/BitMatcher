#ifndef EC_MODULE_H
#define EC_MODULE_H

#include "redismodule.h"

#define EC_ENC_VER 0
#define REDIS_MODULE_TARGET

int ECModule_onLoad(RedisModuleCtx *ctx, RedisModuleString **argv, int argc);

#endif
