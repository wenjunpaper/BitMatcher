# BitMatcher Item Size Distribution

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./bitmatcher ./XX.data (Memory)
```

`XX.data` is a dataset, Memory is the memory usage (unit is MB).

Besides, you can also repeat the item distribution experiments of Bitmatcher by running run.sh in this folder. The result will be written into distribute.txt. The content of each line is: memory, EL error, DHS error, SW error, and BM error. It should be noted that you need to switch the dataset in the script to your own.

## Output format

Our program will print the WMRE of BitMatcher and other two sketches.
