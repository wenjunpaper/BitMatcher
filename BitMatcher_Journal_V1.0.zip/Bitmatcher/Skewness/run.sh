rm insert.txt
rm query.txt
rm aae.txt
rm are.txt


./bitmatcher /share/zipf_2022/zipf_0.0.dat 0.1
./bitmatcher /share/zipf_2022/zipf_0.2.dat 0.1
./bitmatcher /share/zipf_2022/zipf_0.4.dat 0.1
./bitmatcher /share/zipf_2022/zipf_0.6.dat 0.1
./bitmatcher /share/zipf_2022/zipf_0.8.dat 0.1
./bitmatcher /share/zipf_2022/zipf_1.0.dat 0.1
./bitmatcher /share/zipf_2022/zipf_1.2.dat 0.1
./bitmatcher /share/zipf_2022/zipf_1.4.dat 0.1
./bitmatcher /share/zipf_2022/zipf_1.6.dat 0.1
./bitmatcher /share/zipf_2022/zipf_1.8.dat 0.1
./bitmatcher /share/zipf_2022/zipf_2.0.dat 0.1
./bitmatcher /share/zipf_2022/zipf_2.2.dat 0.1
./bitmatcher /share/zipf_2022/zipf_2.4.dat 0.1
./bitmatcher /share/zipf_2022/zipf_2.6.dat 0.1
./bitmatcher /share/zipf_2022/zipf_2.8.dat 0.1
./bitmatcher /share/zipf_2022/zipf_3.0.dat 0.1


./bitmatcher /share/zipf_2022/zipf_0.0.dat 1
./bitmatcher /share/zipf_2022/zipf_0.2.dat 1
./bitmatcher /share/zipf_2022/zipf_0.4.dat 1
./bitmatcher /share/zipf_2022/zipf_0.6.dat 1
./bitmatcher /share/zipf_2022/zipf_0.8.dat 1
./bitmatcher /share/zipf_2022/zipf_1.0.dat 1
./bitmatcher /share/zipf_2022/zipf_1.2.dat 1
./bitmatcher /share/zipf_2022/zipf_1.4.dat 1
./bitmatcher /share/zipf_2022/zipf_1.6.dat 1
./bitmatcher /share/zipf_2022/zipf_1.8.dat 1
./bitmatcher /share/zipf_2022/zipf_2.0.dat 1
./bitmatcher /share/zipf_2022/zipf_2.2.dat 1
./bitmatcher /share/zipf_2022/zipf_2.4.dat 1
./bitmatcher /share/zipf_2022/zipf_2.6.dat 1
./bitmatcher /share/zipf_2022/zipf_2.8.dat 1
./bitmatcher /share/zipf_2022/zipf_3.0.dat 1



./bitmatcher /share/zipf_2022/zipf_0.0.dat 10
./bitmatcher /share/zipf_2022/zipf_0.2.dat 10
./bitmatcher /share/zipf_2022/zipf_0.4.dat 10
./bitmatcher /share/zipf_2022/zipf_0.6.dat 10
./bitmatcher /share/zipf_2022/zipf_0.8.dat 10
./bitmatcher /share/zipf_2022/zipf_1.0.dat 10
./bitmatcher /share/zipf_2022/zipf_1.2.dat 10
./bitmatcher /share/zipf_2022/zipf_1.4.dat 10
./bitmatcher /share/zipf_2022/zipf_1.6.dat 10
./bitmatcher /share/zipf_2022/zipf_1.8.dat 10
./bitmatcher /share/zipf_2022/zipf_2.0.dat 10
./bitmatcher /share/zipf_2022/zipf_2.2.dat 10
./bitmatcher /share/zipf_2022/zipf_2.4.dat 10
./bitmatcher /share/zipf_2022/zipf_2.6.dat 10
./bitmatcher /share/zipf_2022/zipf_2.8.dat 10
./bitmatcher /share/zipf_2022/zipf_3.0.dat 10
