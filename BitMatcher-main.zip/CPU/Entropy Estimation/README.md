# BitMatcher Entropy Estimation

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./bitmatcher ./XX.data (Memory)
```

`XX.data` is a dataset, Memory is the memory usage (unit is MB).

## Output format

Our program will print the real_entropy and relative error of BitMatcher and other two sketches.
